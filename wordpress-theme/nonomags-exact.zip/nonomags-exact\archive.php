<?php
/**
 * Archive shell.
 *
 * @package NonoMagsExact
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

nonomags_exact_render_app_shell();
